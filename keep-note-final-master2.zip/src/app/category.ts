export class Category {
    categoryId: String;
    categoryName: String;
    categoryDescription: String;
    categoryCreatedBy: String;
  
    constructor() {
        this.categoryId='';
        this.categoryName='';
        this.categoryDescription='';
        this.categoryCreatedBy='';
    }
}