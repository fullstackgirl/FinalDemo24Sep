import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import { NotesService } from '../services/notes.service';
import { Note } from '../note';
import { RouterService } from '../services/router.service';

@Component({
  selector: 'app-category-view',
  templateUrl: './category-view.component.html',
  styleUrls: ['./category-view.component.css']
})
export class CategoryViewComponent implements OnInit {
  removable = true;
  categoryNotes: Array<Note> = [];
  categoryName: String;
  constructor(private activatedRoute: ActivatedRoute, private notesService: NotesService, private routerService: RouterService) { 
    this.activatedRoute.params.subscribe(value=> {
      const categoryId=this.activatedRoute.snapshot.paramMap.get('id');
      this.notesService.getNotes().subscribe(
        data => {
          this.categoryNotes = [];
          this.categoryName=null;
          data.map(note => {
            if (note.category && note.category.categoryId === categoryId) {
              this.categoryNotes.push(note);
              this.categoryName=note.category.categoryName;
            }
          });
        },
        error => {
          this.categoryNotes = [];
        }
      );
    });
  }

  ngOnInit() {
  }
  
  remove()
  {
    this.routerService.routeToNoteView();
  }
}
