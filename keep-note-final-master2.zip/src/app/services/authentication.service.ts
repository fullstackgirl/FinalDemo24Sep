import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class AuthenticationService {

  public isUserLoggedIn: BehaviorSubject<boolean>= new BehaviorSubject<boolean>(true);

  constructor(private http: HttpClient) {

  }

  authenticateUser(data) {
    console.log("authenticateUser");
    return this.http.post('http://localhost:8089/api/v1/auth/login', data);
  }

  registerUser(data) {
    return this.http.post('http://localhost:8089/api/v1/auth/register', data);
  }

  deleteUser() {
    return this.http.delete('http://localhost:8089/api/v1/auth/user/'+this.getCurrentUser());
  }

  setBearerToken(token) {
    localStorage.setItem('bearerToken', token);   
  }

  setCurrentUser(user)
  {
    localStorage.setItem('currentUser', user);
  }

  getBearerToken() {
    return localStorage.getItem('bearerToken');
  }

  getCurrentUser() {
    return localStorage.getItem('currentUser');
  }

  removeUserData() {
    localStorage.removeItem('bearerToken');
    localStorage.removeItem('currentUser');
  }

  isLoggedInUser() {
  console.log("isLoggedInUser");
    return (this.getBearerToken())?true:true;
  }

  isUserAuthenticated(token): Promise<boolean> {

  //check if token available
   const flag=(token)?true:false;
   console.log("isUserAuthenticated");
   return new Promise(function(resolve,reject){resolve(flag)});

  }
}
