import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'; // importing HttpClient Injectable
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import 'rxjs/add/operator/do';

import { AuthenticationService } from './authentication.service';

@Injectable()
export class UserService {

  
  constructor(private httpClient: HttpClient, private authService: AuthenticationService) {
    
  }

  getUser() {
    return this.httpClient.get('http://localhost:8080/api/v1/user/'+this.authService.getCurrentUser(), {
       headers: new HttpHeaders()
       .set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
     });
  }
  
  updateUser(user) {
    return this.httpClient.put('http://localhost:8080/api/v1/user/'+this.authService.getCurrentUser(), user, {
       headers: new HttpHeaders()
       .set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
     });
  }

  deleteUser() {
    return this.httpClient.delete('http://localhost:8080/api/v1/user/'+this.authService.getCurrentUser(), {
       headers: new HttpHeaders()
       .set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
     });
  }
}
