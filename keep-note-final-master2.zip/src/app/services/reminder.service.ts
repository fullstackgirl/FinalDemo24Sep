import { Injectable } from '@angular/core';
import { Reminder } from '../reminder'; // Importing reminder class in Service
import { HttpClient, HttpHeaders } from '@angular/common/http'; // importing HttpClient Injectable
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import 'rxjs/add/operator/do';

import { AuthenticationService } from './authentication.service';

@Injectable()
export class ReminderService {

  reminders: Array<Reminder>;
  reminderSubject: BehaviorSubject<Array<Reminder>>;

  constructor(private httpClient: HttpClient, private authService: AuthenticationService) {
    this.reminders = [];
    this.reminderSubject = new BehaviorSubject(this.reminders);
  }

  fetchRemindersFromServer() {
    return this.httpClient.get<Array<Reminder>>(`http://localhost:8081/api/v1/reminder/all/${this.authService.getCurrentUser()}`, {
       headers: new HttpHeaders()
       .set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
     }).subscribe(reminders => {
       this.reminders = reminders;
       this.reminderSubject.next(this.reminders);
     },
     error => {
      this.reminders = [];
     });
  }

  getReminders(): BehaviorSubject<Array<Reminder>> {
    return this.reminderSubject;
  }

  addReminder(reminder: Reminder): Observable<Reminder> {
    const token = this.authService.getBearerToken();
    reminder.reminderCreatedBy=this.authService.getCurrentUser();
    return this.httpClient.post<Reminder>('http://localhost:8081/api/v1/reminder', reminder, {
      headers: new HttpHeaders()
      .set('Authorization', `Bearer ${token}`)
    }).do(newreminder => {
      this.reminders.push(newreminder);
      this.reminderSubject.next(this.reminders);
    });
  }

  editReminder(reminder: Reminder): Observable<Reminder> {
    reminder.reminderCreatedBy=this.authService.getCurrentUser();
    return this.httpClient.put<Reminder>(`http://localhost:8081/api/v1/reminder/${reminder.reminderId}`, reminder, {
      headers: new HttpHeaders()
      .set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
    }).do(editReminder => {
      Object.assign(this.reminders.find(reminder => reminder.reminderId === editReminder.reminderId), editReminder);
      this.reminderSubject.next(this.reminders);
    });
  }

  deleteReminder(reminder: Reminder): Observable<Reminder> {
    return this.httpClient.delete<Reminder>(`http://localhost:8081/api/v1/reminder/${reminder.reminderId}`,{
      headers: new HttpHeaders()
      .set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
    }).do(data => {
      this.reminders=this.reminders.filter(obj=>obj.reminderId!=reminder.reminderId);
      this.reminderSubject.next(this.reminders);
    });
  }

  deleteAllReminders(){
    return this.httpClient.delete(`http://localhost:8081/api/v1/reminder/all/${this.authService.getCurrentUser()}`, {
      headers: new HttpHeaders()
      .set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
    });
  }

  getReminderById(reminderId): Reminder {
    return Object.assign({}, this.reminders.find(reminder => reminder.reminderId === reminderId));
  }
}
