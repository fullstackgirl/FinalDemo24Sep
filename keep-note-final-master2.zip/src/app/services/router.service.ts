import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { AuthenticationService } from './authentication.service';

@Injectable()
export class RouterService {


  constructor(private router: Router, private location: Location, private authService: AuthenticationService) { }

  routeToDashboard() {
    this.router.navigate(['dashboard']);
  }

  routeToLogin() {
    this.authService.isUserLoggedIn.next(false);
    this.router.navigate(['login']);
  }

  routeToEditNoteView(noteId) {
    this.router.navigate([
      'dashboard',
      {
        outlets: {
          noteEditOutlet: ['note', noteId, 'edit']
        }
      }
    ]);
  }

  routeToEditCategoryView(id) {
    this.router.navigate([
      'dashboard',
      {
        outlets: {
          categoryEditOutlet: ['category', id, 'edit']
        }
      }
    ]);
  }

  
  routeToDeleteCategoryView(id){
    this.router.navigate([
      'dashboard',
      {
        outlets: {
          categoryEditOutlet: ['category', id, 'delete']
        }
      }
    ]);  
  }

  routeToNewCategoryView() {
    this.router.navigate([
      'dashboard',
      {
        outlets: {
          categoryEditOutlet: ['category',0,'new']
        }
      }
    ]);
  }

  routeToEditReminderView(reminderId) {
    this.router.navigate([
      'dashboard',
      {
        outlets: {
          reminderEditOutlet: ['reminder', reminderId, 'edit']
        }
      }
    ]);
  }


  routeToNewReminderView() {

    this.router.navigate([
      'dashboard',
      {
        outlets: {
          reminderEditOutlet: ['reminder',0,'new']
        }
      }
    ]);
  }
  routeBack() {
    this.location.back();
  }

  routeToNoteView() {
    this.router.navigate(['dashboard/view/noteview']);
  }

  routeToListView() {
    this.router.navigate(['dashboard/view/listview']);
  }

  routeToCategoryView(id) {
    this.router.navigate(['dashboard/view/categoryview/'+id]);
  }

  routeToReminderView(id) {
    this.router.navigate(['dashboard/view/reminderview/'+id]);
  }

  }
