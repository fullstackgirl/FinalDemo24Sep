import { Injectable } from '@angular/core';
import { Note } from '../note'; // Importing Note class in Service
import { HttpClient, HttpHeaders } from '@angular/common/http'; // importing HttpClient Injectable
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import 'rxjs/add/operator/do';


import { AuthenticationService } from './authentication.service';

@Injectable()
export class NotesService {

  notes: Array<Note>;
  notesSubject: BehaviorSubject<Array<Note>>;

  constructor(private httpClient: HttpClient, private authService: AuthenticationService) {
    this.notes = [];
    this.notesSubject = new BehaviorSubject(this.notes);
  }

  fetchNotesFromServer() {
    return this.httpClient.get<Array<Note>>(`http://localhost:8082/api/v1/note/${this.authService.getCurrentUser()}`, {
       headers: new HttpHeaders()
       .set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
     }).subscribe(notes => {
       this.notes = notes;
       this.notesSubject.next(this.notes);
     },
     error => {
      this.notes = [];
     });
  }

  getNotes(): BehaviorSubject<Array<Note>> {
    return this.notesSubject;
  }


  addNote(note: Note): Observable<Note> {
    note.noteCreatedBy=this.authService.getCurrentUser();
    return this.httpClient.post<Note>('http://localhost:8082/api/v1/note', note, {
      headers: new HttpHeaders()
      .set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
    }).do(newNote => {
      var noteIndex= this.notes.push(newNote);
      // console.log("noteIndex====="+noteIndex);
      this.notesSubject.next(this.notes);
    });
  }

  editNote(cnote: Note): Observable<Note> {
      cnote.noteCreatedBy=this.authService.getCurrentUser();
      console.log("Edit note="+this.authService.getCurrentUser()+"-"+cnote.noteId+"-"+cnote);
      return this.httpClient.put<Note>(`http://localhost:8082/api/v1/note/${this.authService.getCurrentUser()}/${cnote.noteId}`, cnote, {
        headers: new HttpHeaders()
        .set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
      }).do(editNote => {

        this.notes.forEach(currentItrNote => {
          if(currentItrNote.noteId == editNote.noteId){
            currentItrNote.category = editNote.category;
            currentItrNote.noteContent = editNote.noteContent;
            currentItrNote.noteCreatedBy = editNote.noteCreatedBy;
            currentItrNote.noteStatus = editNote.noteStatus;
            currentItrNote.noteTitle = editNote.noteTitle;
            currentItrNote.reminders = editNote.reminders;
          }
        });
        this.notesSubject.next(this.notes);
      });
    }

  deleteNote(cnote: Note): Observable<Note> {
    return this.httpClient.delete<Note>(`http://localhost:8082/api/v1/note/${this.authService.getCurrentUser()}/${cnote.noteId}`,{
      headers: new HttpHeaders()
      .set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
    }).do(data => {
      this.notes=this.notes.filter(obj=>obj.noteId!=cnote.noteId);
      this.notesSubject.next(this.notes);
    });
  }

  deleteAllNotes(){
    return this.httpClient.delete(`http://localhost:8082/api/v1/note/${this.authService.getCurrentUser()}`, {
      headers: new HttpHeaders()
      .set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
    });
  }

  getNoteById(noteId): Note {
  console.log("getNoteById noteId==="+noteId);
    return Object.assign({}, this.notes.find(note => note.noteId === noteId));
  }
}
