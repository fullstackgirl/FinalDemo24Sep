import { Injectable } from '@angular/core';
import { Category } from '../category'; // Importing Category class in Service
import { HttpClient, HttpHeaders } from '@angular/common/http'; // importing HttpClient Injectable
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import 'rxjs/add/operator/do';

import { AuthenticationService } from './authentication.service';

@Injectable()
export class CategoryService {

  categories: Array<Category>;
  categorySubject: BehaviorSubject<Array<Category>>;

  constructor(private httpClient: HttpClient, private authService: AuthenticationService) {
    this.categories = [];
    this.categorySubject = new BehaviorSubject(this.categories);
  }

  fetchCategoriesFromServer() {
    return this.httpClient.get<Array<Category>>(`http://localhost:8083/api/v1/category/all/${this.authService.getCurrentUser()}`, {
       headers: new HttpHeaders()
       .set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
     }).subscribe(categories => {
       this.categories = categories;
       this.categorySubject.next(this.categories);
     },
     error => {
      this.categories = [];
     });
  }

  getCategories(): BehaviorSubject<Array<Category>> {
    return this.categorySubject;
  }

  addCategory(category: Category): Observable<Category> {
    const token = this.authService.getBearerToken();
    category.categoryCreatedBy=this.authService.getCurrentUser();
    return this.httpClient.post<Category>('http://localhost:8083/api/v1/category', category, {
      headers: new HttpHeaders()
      .set('Authorization', `Bearer ${token}`)
    }).do(newCategory => {
      this.categories.push(newCategory);
      this.categorySubject.next(this.categories);
    });
  }

  editCategory(category: Category): Observable<Category> {
    category.categoryCreatedBy=this.authService.getCurrentUser();
    return this.httpClient.put<Category>(`http://localhost:8083/api/v1/category/${category.categoryId}`, category, {
      headers: new HttpHeaders()
      .set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
    }).do(editCategory => {
      Object.assign(this.categories.find(category => category.categoryId === editCategory.categoryId), editCategory);
      this.categorySubject.next(this.categories);
    });
  }

  deleteCategory(category: Category): Observable<Category> {
    return this.httpClient.delete<Category>(`http://localhost:8083/api/v1/category/${category.categoryId}`,{
      headers: new HttpHeaders()
      .set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
    }).do(data => {
      this.categories=this.categories.filter(obj=>obj.categoryId!=category.categoryId);
      this.categorySubject.next(this.categories);
    });
  }

  deleteAllCategories(){
    return this.httpClient.delete(`http://localhost:8083/api/v1/category/all/${this.authService.getCurrentUser()}`, {
      headers: new HttpHeaders()
      .set('Authorization', `Bearer ${this.authService.getBearerToken()}`)
    });
  }

  getCategoryById(categoryId): Category {
    return Object.assign({}, this.categories.find(category => category.categoryId === categoryId));
  }
}
