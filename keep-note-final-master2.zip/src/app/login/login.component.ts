import { Component,OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AuthenticationService} from '../services/authentication.service';
import { RouterService } from '../services/router.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  toggleDiv: Boolean = true;
  submitMessage: string;
  errorMessage: string;
  public userId;
  public userPassword;
  public firstName;
  public lastName;
  public userRole="USER";

  loginForm: FormGroup = new FormGroup(
    {
      userId: new FormControl(),
      userPassword: new FormControl()
    }
  );

  registerForm: FormGroup = new FormGroup(
    {
      userId: new FormControl(),
      userPassword: new FormControl(),
      firstName: new FormControl(),
      lastName: new FormControl(),
      userRole: new FormControl()
    }
  );
  showHideContent()
  {
    this.errorMessage ="";
    this.submitMessage ="";
    this.toggleDiv=this.toggleDiv?false:true;
  }
  constructor( private authService: AuthenticationService, private routerService: RouterService) { }

  ngOnInit() {
    if(this.authService.isLoggedInUser()) this.routerService.routeToDashboard()
  }

  loginSubmit() {
    this.authService.authenticateUser(this.loginForm.value).subscribe(
      data => {
      console.log("token"+data)
      console.log("token"+data['token'])
      console.log("user"+data['currentUser'])
        this.authService.setBearerToken(data['token']);
        this.authService.setCurrentUser(data['currentUser']);
        this.authService.isUserLoggedIn.next(true);
        console.log("auth");
        this.routerService.routeToNoteView();

      },
      error => {
        if (error.status === 401) {
          this.errorMessage = "UserName/Password is incorrect";
        }else {
          this.errorMessage = error.message;
        }
      }
    );
  }

  registerSubmit() {
    this.authService.registerUser(this.registerForm.value).subscribe(
      data => {
        this.submitMessage = "User Registered succesfully.";
        this.registerForm.reset();
        this.toggleDiv=true;
      },
      error => {
        if (error.status === 409) {
          this.errorMessage = "User already exists in the data base";
        }else {
          this.errorMessage = error.message;
        }
      }
    );
  }
  
}

