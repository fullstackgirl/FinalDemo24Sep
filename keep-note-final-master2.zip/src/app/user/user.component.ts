import { Component,OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AuthenticationService} from '../services/authentication.service';
import { RouterService } from '../services/router.service';
import { UserService } from '../services/user.service';
import { User } from '../user';
import { CategoryService } from '../services/category.service';
import { ReminderService } from '../services/reminder.service';
import { NotesService } from '../services/notes.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  user: User;
  submitMessage: string;
  errorMessage: string;
  showSpinner: boolean;

  userForm: FormGroup = new FormGroup(
    {
      userId: new FormControl(),
      userPassword: new FormControl(),
      userName: new FormControl(),
      userMobile: new FormControl(),
      userAddedDate: new FormControl()
    }
  );

  constructor( private authService: AuthenticationService, 
    private routerService: RouterService, private userService: UserService,
    private categoryService: CategoryService, private reminderService: ReminderService,
    private notesService: NotesService) { }

  ngOnInit() {
    //this.userForm.patchValue({userId: 'test'});
    this.userService.getUser().subscribe(
      data => {
        this.userForm.patchValue(
        {
          userId: data['userId'],
          userPassword: data['userPassword'],
          userName: data['userName'],
          userMobile: data['userMobile']
        });
      }
    );
  }


  userSubmit() {   
    this.userService.updateUser(this.userForm.value).subscribe(
      data => {
        this.submitMessage="User data is updated successfully"
      },
      error => {
        if (error.status === 409) {
          this.errorMessage = "User already exists in the database";
        }else if (error.status === 404) {
          this.errorMessage = "User not found";
        }else {
          this.errorMessage = error.message;
        }
      }
    );
  }

  userDelete() {
    this.showSpinner=true;
    this.categoryService.deleteAllCategories().subscribe(
      data => {
        console.log("testing Categories for that user are deleted");
      },
      error => {        
          this.errorMessage = error.message;
      }
    );
    this.reminderService.deleteAllReminders().subscribe(
      data => {
        console.log("testing Reminders for the users are deleted");
      },
      error => {        
          this.errorMessage = error.message;
      }
    );
    this.notesService.deleteAllNotes().subscribe(
      data => {
        console.log("testing notes are  deleted");
      },
      error => {        
          this.errorMessage = error.message;
      }
    );
    this.userService.deleteUser().subscribe(
      data => {
        console.log("testing user is deleted");
      },
      error => {        
          this.errorMessage = error.message;
      }
    );
    setTimeout(()=>{
      this.authService.deleteUser().subscribe(
        data => {
          this.showSpinner=false;
          console.log("testing the users authentication details are deleted");
          this.authService.removeUserData();
          this.routerService.routeToLogin();
        },
        error => {        
            this.errorMessage = error.message;
        }
      );
    },1000);
    
  }
  
}
