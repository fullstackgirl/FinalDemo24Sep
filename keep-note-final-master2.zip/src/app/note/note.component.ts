import { Component, OnInit, Input } from '@angular/core';

import { Note } from '../note';

import { RouterService } from '../services/router.service';
import {NotesService} from '../services/notes.service';

@Component({
  selector: 'app-note',
  templateUrl: './note.component.html',
  styleUrls: ['./note.component.css']
})
export class NoteComponent implements OnInit {
  removable = true;
  @Input()
  note: Note;
  constructor(private routerService: RouterService, private notesService: NotesService) { }

  ngOnInit() {
  }

  OpenEditView() {
  console.log(this.note.noteTitle)
    this.routerService.routeToEditNoteView(this.note.noteId);
  }

  removeNoteCategory(noteId)
  {
    let note=this.notesService.getNoteById(noteId);
    note.category=null;
    this.notesService.editNote(note).subscribe(editNote=> {});
  }

  removeNoteReminder(noteId,reminderId)
  {
    let note=this.notesService.getNoteById(noteId);
    for(let reminder of note.reminders)
    {
      if(reminder.reminderId===reminderId)
      {
        note.reminders=note.reminders.filter(obj=>obj.reminderId!=reminder.reminderId);
      }
    }
    this.notesService.editNote(note).subscribe(editNote=> {});
  }
}

