import { Component, OnInit, Inject } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';

import { ReminderService } from '../services/reminder.service';

import { Reminder } from '../reminder';
import { Note } from '../note';
import { RouterService } from '../services/router.service';
import { NotesService } from '../services/notes.service';

@Component({
  selector: 'app-edit-reminder-view',
  templateUrl: './edit-reminder-view.component.html',
  styleUrls: ['./edit-reminder-view.component.css']
})
export class EditReminderViewComponent implements OnInit {

    reminder: Reminder;
    errorMessage: string;
    notes: Array<Note> = [];
  
    constructor(private dialogRef: MatDialogRef<EditReminderViewComponent>,
      private reminderService: ReminderService,private routerService: RouterService,
      private notesService: NotesService,
      @Inject(MAT_DIALOG_DATA) private data: any
    ) { }
  
    ngOnInit() {
      if(this.data.id)
      {
        this.reminder = this.reminderService.getReminderById(this.data.id);
      }
      else{
        this.reminder =new Reminder();
      }
    }
  
    onSave() {
      this.reminderService.addReminder(this.reminder).subscribe(
      editNote => {
        this.dialogRef.close();
      },
      error => {
        if (error.status === 403) {
          this.errorMessage = error.error.message;
        }else {
          this.errorMessage = error.message;
        }
      });
    }
    
    onEdit() {
      this.notesService.getNotes().subscribe(
        data =>{
          this.notes=data;
        }
      );
      
      for(let note of this.notes)
      {
        if(note.reminders)
        {
          for(let i=0;i<note.reminders.length;i++)
          {
            if(note.reminders[i].reminderId===this.reminder.reminderId)
            {
              note.reminders[i]=this.reminder;          
            }       
          }
          this.notesService.editNote(note).subscribe(editNote=> {});
        }
      }
      
      this.reminderService.editReminder(this.reminder).subscribe(
      editNote => {
        this.dialogRef.close();
      },
      error => {
        if (error.status === 403) {
          this.errorMessage = error.error.message;
        }else {
          this.errorMessage = error.message;
        }
      });
    }  
    
    onDelete() {

      this.notesService.getNotes().subscribe(
        data =>{
          this.notes=data;
        }
      );

      
      for(let note of this.notes)
      {
        if(note.reminders){
          for(let reminder of note.reminders)
          {
            if(reminder.reminderId===this.reminder.reminderId)
            {
              note.reminders=note.reminders.filter(obj=>obj.reminderId!=this.reminder.reminderId);      
            }       
          }
          this.notesService.editNote(note).subscribe(editNote=> {});
       }
      }

      this.reminderService.deleteReminder(this.reminder).subscribe(
      editNote => {
        this.dialogRef.close();
      },
      error => {      
          this.errorMessage = error.message;
      });
    }

}
