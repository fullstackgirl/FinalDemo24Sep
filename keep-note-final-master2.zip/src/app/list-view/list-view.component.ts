import { Component, OnInit } from '@angular/core';
import { Note } from '../note'; // data class
import { NotesService } from '../services/notes.service';

@Component({
  selector: 'app-list-view',
  templateUrl: './list-view.component.html',
  styleUrls: ['./list-view.component.css']
})
export class ListViewComponent implements OnInit {

  notStartedNotes: Array<Note> = [];
  startedNotes: Array<Note> = [];
  completedNotes: Array<Note> = [];
  errorMessage: string;

  constructor(private notesService: NotesService) {}

  // On init when page loads
  ngOnInit() {
    this.notesService.getNotes().subscribe(
      data => {
        this.notStartedNotes = [];
        this.startedNotes = [];
        this.completedNotes = [];
        data.map(note => {
          if (note.noteStatus === 'Not Started') {
            this.notStartedNotes.push(note);
          } else if (note.noteStatus === 'Started') {
            this.startedNotes.push(note);
          } else if (note.noteStatus === 'Completed') {
            this.completedNotes.push(note);
          }
        });
      },
      error => {
        if (error.status === 403) {
          this.errorMessage = error.error.message;
        }else {
          this.errorMessage = error.message;
        }
        this.notStartedNotes = [];
        this.startedNotes = [];
        this.completedNotes = [];
      });
  }

}
