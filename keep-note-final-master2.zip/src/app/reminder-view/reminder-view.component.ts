import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import { NotesService } from '../services/notes.service';
import { Note } from '../note';
import { RouterService } from '../services/router.service';

@Component({
  selector: 'app-reminder-view',
  templateUrl: './reminder-view.component.html',
  styleUrls: ['./reminder-view.component.css']
})
export class ReminderViewComponent implements OnInit {

  removable = true;
  ReminderNotes: Array<Note> = [];
  ReminderName: String;
  constructor(private activatedRoute: ActivatedRoute, private notesService: NotesService, private routerService: RouterService) { 
    this.activatedRoute.params.subscribe(value=> {
      const reminderId=this.activatedRoute.snapshot.paramMap.get('id');
      console.log("(((((reminderId : "+reminderId);
      this.notesService.getNotes().subscribe(
        data => {
          this.ReminderNotes = [];
          this.ReminderName=null;
          data.map(note => {
            
            note.reminders.forEach(reminder => {
              console.log("reminder.reminderId  >>>>> "+reminder.reminderId);
              if(reminder.reminderId === reminderId){
                this.ReminderNotes.push(note);
                this.ReminderName = reminder.reminderName;
              }
            });
          });
        },
        error => {
          this.ReminderNotes = [];
        }
      );
    });
  }
  

  ngOnInit() {
  }

  remove()
  {
    this.routerService.routeToNoteView();
  }
}
