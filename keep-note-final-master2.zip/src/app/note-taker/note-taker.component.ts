import { Component, OnInit } from '@angular/core';

import {NotesService} from '../services/notes.service';
import {Note} from '../note';

@Component({
  selector: 'app-note-taker',
  templateUrl: './note-taker.component.html',
  styleUrls: ['./note-taker.component.css']
})
export class NoteTakerComponent implements OnInit {
  errorMessage: string;
  note: Note = new Note();
  notes: Array<Note> = [];

  constructor(private notesService: NotesService) { }

  ngOnInit() {
  }

  takeNote() {
  console.log("this.note.noteId="+this.note.noteId)
    if (this.note.noteTitle === '' || this.note.noteContent === '') {
      this.errorMessage = 'Title and Text both are required fields';
    }else {
      this.notes.push(this.note);
      this.notesService.addNote(this.note).subscribe(
        data => {},
        err => {
          if (err.status === 403) {
            this.errorMessage = err.error.message;
          }else {
            this.errorMessage = err.message;
          }
          const noteIndex = this.notes.findIndex(note => note.noteTitle === this.note.noteTitle);
          alert("noteIndex="+noteIndex);
          this.notes.splice(noteIndex, 1);
        }
      );
    }
    this.note = new Note();
  }
}
