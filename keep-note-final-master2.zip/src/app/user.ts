export class User {
    userId: String;
    userPassword: String;
    userName: String;
    userMobile: String;
    userAddedDate: String;
  
    constructor() {
        this.userId='';
        this.userPassword='';
        this.userName='';
        this.userMobile='';
        this.userAddedDate='';
    }
  }