import { Component, OnInit, Input } from '@angular/core';

import { Category } from '../category';

import { RouterService } from '../services/router.service';

import { CategoryService } from '../services/category.service';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {

  categories: Array<Category> = [];

  @Input()
  category: Category;
  constructor(private routerService: RouterService, private categoryService:CategoryService) { }

  ngOnInit() {
    this.categoryService.fetchCategoriesFromServer();
    this.categoryService.getCategories().subscribe(
      data => {
        this.categories = data;
      },
      error => {
        this.categories = [];
      }
    );
  }

  openEditView(id) {
    this.routerService.routeToEditCategoryView(id);
  }

  openNewView() {
    this.routerService.routeToNewCategoryView();
  }

  onDelete(id) {
    this.routerService.routeToDeleteCategoryView(id);
  }

  showCategoryview(id)
  {
    this.routerService.routeToCategoryView(id);
  }
}
