import { Component, OnInit, Inject } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';

import { CategoryService } from '../services/category.service';

import { Category } from '../category';
import { Note } from '../note';
import { RouterService } from '../services/router.service';
import { NotesService } from '../services/notes.service';

@Component({
  selector: 'app-edit-category-view',
  templateUrl: './edit-category-view.component.html',
  styleUrls: ['./edit-category-view.component.css']
})
export class EditCategoryViewComponent implements OnInit {

    category: Category;
    errorMessage: string;
    notes: Array<Note> = [];
  
    constructor(private dialogRef: MatDialogRef<EditCategoryViewComponent>,
      private categoryService: CategoryService,private routerService: RouterService,private notesService: NotesService,
      @Inject(MAT_DIALOG_DATA) private data: any
    ) { }
  
    ngOnInit() {
      if(this.data.id)
      {
        this.category = this.categoryService.getCategoryById(this.data.id);
      }
      else{
        this.category =new Category();
      }
    }
  
    onSave() {
      this.categoryService.addCategory(this.category).subscribe(
      editNote => {
        this.dialogRef.close();
      },
      error => {
        if (error.status === 403) {
          this.errorMessage = error.error.message;
        }else {
          this.errorMessage = error.message;
        }
      });
    }
    
    onEdit() {
      
      this.notesService.getNotes().subscribe(
        data =>{
          this.notes=data;
        }
      );

      for(let note of this.notes)
      {
        if(note.category && (note.category.categoryId===this.category.categoryId))
        {
          note.category=this.category;         
        }
        this.notesService.editNote(note).subscribe(editNote=> {});
      }

      this.categoryService.editCategory(this.category).subscribe(
      editNote => {
        this.dialogRef.close();
      },
      error => {
        if (error.status === 403) {
          this.errorMessage = error.error.message;
        }else {
          this.errorMessage = error.message;
        }
      });
    }  
    
    onDelete() {

      this.notesService.getNotes().subscribe(
        data =>{
          this.notes=data;
        }
      );
      
      for(let note of this.notes)
      {
        if(note.category && (note.category.categoryId===this.category.categoryId))
        {
          note.category=null;        
        }
        this.notesService.editNote(note).subscribe(editNote=> {});
      }
        
      this.categoryService.deleteCategory(this.category).subscribe(
      editNote => {
        this.dialogRef.close();
      },
      error => {      
          this.errorMessage = error.message;
      });
    }

}
