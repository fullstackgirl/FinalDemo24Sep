import { Component, OnInit } from '@angular/core';
import { Note } from '../note'; // data class
import { NotesService } from '../services/notes.service';
import { RouterService } from '../services/router.service';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { AuthenticationService} from '../services/authentication.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  isNoteView: Boolean = true;
  isUserLoggedIn: Boolean = true;

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches)
    );

  constructor(private notesService: NotesService, 
      private routerService: RouterService, 
      private breakpointObserver: BreakpointObserver,
      private authService: AuthenticationService) {
    this.notesService.fetchNotesFromServer();
    this.routerService.routeToNoteView();
  }

  ngOnInit() {
    this.isUserLoggedIn= this.authService.isLoggedInUser();
  }

  viewListView() {
    this.isNoteView = false;
    this.routerService.routeToListView();
  }

  viewNotesView() {
    this.isNoteView = true;
    this.routerService.routeToNoteView();
  }

  logout() {
    this.authService.removeUserData();
    this.routerService.routeToLogin();
  }

}
