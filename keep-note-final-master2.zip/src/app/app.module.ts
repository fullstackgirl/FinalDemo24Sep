import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { NoteComponent } from './note/note.component';
import {MatToolbarModule} from '@angular/material/toolbar';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {MatButtonModule} from '@angular/material/button';
import {MatCardModule} from '@angular/material/card';
import {MatSelectModule} from '@angular/material/select';
import {MatChipsModule} from '@angular/material/chips';
import {MatProgressBarModule} from '@angular/material/progress-bar';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {NotesService} from './services/notes.service';
import {UserService} from './services/user.service';
import {CategoryService} from './services/category.service';
import {ReminderService} from './services/reminder.service';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { RouterModule, Routes, Router} from '@angular/router';
import { AuthenticationService} from './services/authentication.service';
import { RouterService} from './services/router.service';
import { CanActivateRouteGuard} from './can-activate-route.guard';
import { LayoutModule } from '@angular/cdk/layout';

import { NoteTakerComponent } from './note-taker/note-taker.component';
import { NoteViewComponent } from './note-view/note-view.component';
import { ListViewComponent } from './list-view/list-view.component';

import { EditNoteViewComponent } from './edit-note-view/edit-note-view.component';


// import for Material Dialog

import {MatDialog, MatDialogRef, MatDialogModule, MatMenuModule, MatIconModule, MatSidenavModule, MatListModule} from '@angular/material';

import { EditNoteOpenerComponent } from './edit-note-opener/edit-note-opener.component';
import { UserComponent } from './user/user.component';
import { CategoryComponent } from './category/category.component';
import { ReminderComponent } from './reminder/reminder.component';
import { EditCategoryViewComponent } from './edit-category-view/edit-category-view.component';
import { EditReminderViewComponent } from './edit-reminder-view/edit-reminder-view.component';
import { EditCategoryOpenerComponent } from './edit-category-opener/edit-category-opener.component';
import { EditReminderOpenerComponent } from './edit-reminder-opener/edit-reminder-opener.component';
import { CategoryViewComponent } from './category-view/category-view.component';
import { ReminderViewComponent } from './reminder-view/reminder-view.component';

const appRoutes: Routes = [
  {
    path: 'dashboard',
    component: DashboardComponent,
    canActivate: [CanActivateRouteGuard],
    children: [
      {
        path: 'view/noteview',
        component: NoteViewComponent
      },
      {
        path: 'view/listview',
        component: ListViewComponent
      },
      {
        path: 'view/categoryview/:id',
        component: CategoryViewComponent
      },
      {
        path: 'view/reminderview/:id',
        component: ReminderViewComponent
      },
      {
        path: 'note/:noteId/edit',
        component: EditNoteOpenerComponent,
        outlet: 'noteEditOutlet'
      },
      {
        path: 'category/:id/edit',
        component: EditCategoryOpenerComponent,
        outlet: 'categoryEditOutlet'
      },
      {
        path: 'category/:id/delete',
        component: EditCategoryOpenerComponent
        
        
        
        ,
        outlet: 'categoryEditOutlet'
      },
      {
        path: 'category/:id/new',
        component: EditCategoryOpenerComponent,
        outlet: 'categoryEditOutlet'
      },
      {
        path: 'reminder/:reminderId/edit',
        component: EditReminderOpenerComponent,
        outlet: 'reminderEditOutlet'
      },
      {
        path: 'reminder/:reminderId/new',
        component: EditReminderOpenerComponent,
        outlet: 'reminderEditOutlet'
      }
    ]
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'user',
    canActivate: [CanActivateRouteGuard],
    component: UserComponent
  },
  {
    path: '',
    redirectTo: 'dashboard',
    pathMatch: 'full'
  }
];

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    LoginComponent,
    NoteComponent,
    DashboardComponent,
    NoteTakerComponent,
    NoteViewComponent,
    ListViewComponent,
    EditNoteViewComponent,
    EditNoteOpenerComponent,
    UserComponent,
    CategoryComponent,
    ReminderComponent,
    EditCategoryViewComponent,
    EditReminderViewComponent,
    EditCategoryOpenerComponent,
    EditReminderOpenerComponent,
    CategoryViewComponent,
    ReminderViewComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    MatToolbarModule,
    BrowserAnimationsModule,
    MatExpansionModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatCardModule,
    MatSelectModule,
    MatChipsModule,
    MatProgressBarModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(appRoutes),
    MatDialogModule,
    MatMenuModule,
    MatIconModule,
    MatSidenavModule,
    MatListModule,
    LayoutModule
  ],
  providers: [
    NotesService,
    AuthenticationService,
    UserService,
    RouterService,
    CategoryService,
    ReminderService,
    CanActivateRouteGuard
   ],
  bootstrap: [ AppComponent],
  entryComponents: [EditNoteViewComponent,EditCategoryViewComponent,EditReminderViewComponent]
})

export class AppModule { }
