import { Component, OnInit, Inject } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';

import { NotesService } from '../services/notes.service';

import { Note } from '../note';
import { Category } from '../category';
import { Reminder } from '../reminder';
import { CategoryService } from '../services/category.service';
import { ReminderService } from '../services/reminder.service';

@Component({
  selector: 'app-edit-note-view',
  templateUrl: './edit-note-view.component.html',
  styleUrls: ['./edit-note-view.component.css']
})
export class EditNoteViewComponent implements OnInit {
  note: Note;
  categories: Array<Category>;
  reminders: Array<Reminder>;
  states: Array<string> = ['Not Started', 'Started', 'Completed'];
  errorMessage: string;

  constructor(private dialogRef: MatDialogRef<EditNoteViewComponent>,
    private notesService: NotesService,private categoryService: CategoryService,
    private reminderService: ReminderService,
    @Inject(MAT_DIALOG_DATA) private data: any
  ) { }

  ngOnInit() {
    this.note = this.notesService.getNoteById(this.data.noteId);
    this.categoryService.getCategories().subscribe(
      data => {
        this.categories = data;
      },
      error => {
        this.categories = [];
      }
    );
    this.reminderService.getReminders().subscribe(
      data => {
        this.reminders = data;
      },
      error => {
        this.reminders = [];
      }
    );
  }

  onSave() {
    this.notesService.editNote(this.note).subscribe(
    editNote => {
      console.log("this.note: "+this.note);
      console.log("this.dialogRef : "+this.dialogRef);
      console.log("this : "+this.note.noteTitle);
      console.log("editNote back : "+editNote.noteTitle);
      this.dialogRef.close();
    },
    error => {
      if (error.status === 403) {
        this.errorMessage = error.error.message;
      }else {
        this.errorMessage = error.message;
      }
    });
  }

  onDelete() {
    this.notesService.deleteNote(this.note).subscribe(
    editNote => {
      this.dialogRef.close();
    },
    error => {      
        this.errorMessage = error.message;
    });
  }

  compareFn1(obj1: Category, obj2: Category)
  {
    return (obj1 && obj2 ?obj1.categoryId===obj2.categoryId:obj1===obj2);
  }

  compareFn2(obj1: Reminder, obj2: Reminder)
  {
    return (obj1 && obj2 ?obj1.reminderId===obj2.reminderId:obj1===obj2);
  }
}
