import { Component, OnInit } from '@angular/core';
import { RouterService } from '../services/router.service';
import { AuthenticationService} from '../services/authentication.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  isNoteView: Boolean = true;
  isUserLoggedIn: Boolean = true;
  constructor( private authService: AuthenticationService, private routerService: RouterService) {
    this.authService.isUserLoggedIn.subscribe(value =>{
       this.isUserLoggedIn= value;
    });
  }

  ngOnInit() {
    this.isUserLoggedIn= this.authService.isLoggedInUser();
  }

  viewListView() {
    this.isNoteView = false;
    this.routerService.routeToListView();
  }

  viewNotesView() {
    this.isNoteView = true;
    this.routerService.routeToNoteView();
  }

  logout() {
    this.authService.removeUserData();
    this.routerService.routeToLogin();
  }
}
