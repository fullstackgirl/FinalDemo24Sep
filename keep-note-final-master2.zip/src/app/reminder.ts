export class Reminder {
    reminderId: String;
    reminderName: String;
    reminderDescription: String;
    reminderCreatedBy: String;
  
    constructor() {
        this.reminderId='';
        this.reminderName='';
        this.reminderDescription='';
        this.reminderCreatedBy='';
    }
}